﻿using System;
using System.Collections.Generic;

namespace ParseTable
{
    public class JsonFormsDownsream
    {
        //Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 
        //public class White
        //{
        //    public string name { get; set; }
        //    public string flags { get; set; }
        //    public string rank { get; set; }
        //}

        //public class Black
        //{
        //    public string name { get; set; }
        //    public string flags { get; set; }
        //    public string rank { get; set; }
        //}

        public class Player
        {
            public string name { get; set; }
            //public string flags { get; set; }
            //public string rank { get; set; }
        }

        public class Players
        {
            public Player white { get; set; }
            public Player black { get; set; }
        }

        public class Game
        {
            //public string gameType { get; set; }
            public object score { get; set; }
            //public double komi { get; set; }
            //public int size { get; set; }
            public Players players { get; set; }
            //public int handicap { get; set; }
            public DateTime timestamp { get; set; }
            //public int? revision { get; set; }

            public override string ToString()
            {
                //return revision == null ? $"https://files.gokgs.com/games/{timestamp.Year}/{timestamp.Month}/{timestamp.Day}/{players.white.name}-{players.black.name}.sgf" :
                // $"https://files.gokgs.com/games/{timestamp.Year}/{timestamp.Month}/{timestamp.Day}/{players.white.name}-{players.black.name}-{revision}.sgf";
                return $"https://files.gokgs.com/games/{timestamp.Year}/{timestamp.Month}/{timestamp.Day}/{players.white.name}-{players.black.name}.sgf";
            }
        }

        //public class User
        //{
        //    public string name { get; set; }
        //    public string flags { get; set; }
        //    public string rank { get; set; }
        //}

        public class Games
        {
            public List<Game> games { get; set; }
        }

        public class Message
        {
            public List<Game> games { get; set; }
            public string type { get; set; }
            //public User user { get; set; }
            public int channelId { get; set; }
        }

        public class Root
        {
            public List<Message> messages { get; set; }
        }

    }
}
