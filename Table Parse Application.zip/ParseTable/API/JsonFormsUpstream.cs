﻿using System;
namespace ParseTable
{
    public class Login
    {
        public string type { get; set; }
        public string name { get; set; }
        public string password { get; set; }
        public string locale { get; set; }

        public Login(string type = "LOGIN", string name = "LemonDoge",
                     string password = "rwcjb9", string locale = "en_US")
        {
            this.type = type;
            this.name = name;
            this.password = password;
            this.locale = locale;
        }
    }
    public class JoinArchieveRequest
    {
        public string type { get; set; }
        public string name { get; set; }

        public JoinArchieveRequest(string name, string type = "JOIN_ARCHIVE_REQUEST")
        {
            this.type = type;
            this.name = name;
        }
    }

    //public class UnjoinRequest
    //{
    //    public string type { get; set; }
    //    public int channelId { get; set; }

    //    public UnjoinRequest(int channelId, string type = "UNJOIN_REQUEST")
    //    {
    //        this.type = type;
    //        this.channelId = channelId;
    //    }
    //}

    //public class RoomLoadGame
    //{
    //    public string type { get; set; }
    //    public string @private { get; set; }
    //    public string timestamp { get; set; }
    //    public string channelId { get; set; }

    //    public RoomLoadGame(string timestamp, string channelId,
    //                                          string @private = "true",
    //                                          string type = "ROOM_LOAD_GAME")
    //    {
    //        this.timestamp = timestamp;
    //        this.channelId = channelId;
    //        this.@private = @private;
    //        this.type = type;
    //    }
    //}

    public class Logout
    {
        public string type { get; set; } = "LOGOUT";
    }



}
