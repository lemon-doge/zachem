﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using static ParseTable.JsonFormsDownsream;

namespace ParseTable
{
    public class API
    {
        static HttpClient client;
        static API()
        {
            client = new HttpClient();
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
        }
           
        //  basic GET request
        async static Task<string> GetRequest(string url)
        {

            using (HttpResponseMessage resp = await client.GetAsync(url))
            {
                if (resp.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    string str = await resp.Content.ReadAsStringAsync();
                    return str;
                }
                else
                {
                    throw new ArgumentException($"Error on GET rq. Status code: {resp.StatusCode}");
                }
            }

        }

        // Login to the server
        public static async Task Login()
        {
            string json = JsonConvert.SerializeObject(new Login());
            var httpContent = new StringContent(json, Encoding.UTF8, "application/json");
            await PostRequest("https://www.gokgs.com/json/access", httpContent);
            await GetRequest("https://www.gokgs.com/json/access");
        }

        // Getting all games of the player
         public static async Task<Message> GetAllGames(string player)
        {
            
            string json = JsonConvert.SerializeObject(new JoinArchieveRequest(player));
            var httpContent = new StringContent(json, Encoding.UTF8, "application/json");
            await PostRequest("https://www.gokgs.com/json/access", httpContent);
            Root root = await GetPartionsRequest("https://www.gokgs.com/json/access");

            // в message лежит user и List<Game> - games
            return root.messages[0];
        }

        // Logout 
        public static async Task Logout()
        {
            var json = JsonConvert.SerializeObject(new Logout());
            var httpContent = new StringContent(json, Encoding.UTF8, "application/json");
            await PostRequest("https://www.gokgs.com/json/access", httpContent);
            await GetRequest("https://www.gokgs.com/json/access");
        }


        //  Kostil post  request
        async static Task<Root> GetPartionsRequest(string url)
        {

            using (HttpResponseMessage resp = await client.GetAsync(url))
            {
                if (resp.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    var root = await resp.Content.ReadAsAsync<Root>();
                    return root;
                }
                else
                {
                    throw new ArgumentException($"Error on GET parsions rq. Status code: {resp.StatusCode}");
                }
            }

        }

        //  basic  POST request
        async static Task<string> PostRequest(string url, HttpContent httpContent)
        {
            using (HttpResponseMessage resp = await client.PostAsync(url, httpContent))
            {
                using (HttpContent content = resp.Content)
                {
                    if (resp.StatusCode == System.Net.HttpStatusCode.OK)
                    {
                        string str = await resp.Content.ReadAsStringAsync();
                        return str;
                    }
                    else
                    {
                        throw new ArgumentException($"Error on POST rq. Status code: {resp.StatusCode}");
                    }
                }
            }
        }
    }
}
